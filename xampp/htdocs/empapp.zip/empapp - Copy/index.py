#!C:/Users/HETISSH/AppData/Local/Programs/Python/Python310/python.exe
print("Content-type: text/html \r\n\r\n")


print("""
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Home</title>
        <link rel = "icon" type="text/ico" href = "files/icn.png">

</head>
<body>
<h1>Welcome to my website!</h1>
<p>Please select an option below:</p>
<ul>
    <li><a href="login.py">Login</a></li>
    <li><a href="createuser.py">Register</a></li>
</ul>
</body>
</html>
""")